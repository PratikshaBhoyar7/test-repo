// Wait until DOM is ready
document.addEventListener('DOMContentLoaded', function() {

    // ============ Mobile menu toggle ============
    const mobileMenuBtn = document.querySelector('.mobile-menu-btn');
    const mainNav = document.querySelector('.main-nav');
    const dropdownMenus = document.querySelectorAll('.dropdown-menu');

    if (mobileMenuBtn && mainNav) {
        mobileMenuBtn.addEventListener('click', function() {
            mainNav.classList.toggle('active');

            // Close all dropdowns when mobile menu is toggled
            if (window.innerWidth <= 768) {
                dropdownMenus.forEach(menu => {
                    menu.style.display = 'none';
                });
            }
        });
    }

    // ============ Mobile dropdown toggle ============
    const navItems = document.querySelectorAll('.main-nav > li');

    navItems.forEach(item => {
        const link = item.querySelector('a');
        const dropdown = item.querySelector('.dropdown-menu');

        if (link && dropdown && window.innerWidth <= 768) {
            link.addEventListener('click', function(e) {
                e.preventDefault();
                dropdown.style.display = (dropdown.style.display === 'block') ? 'none' : 'block';
            });
        }
    });

    // ============ Close dropdowns when clicking outside (for desktop) ============
    document.addEventListener('click', function(e) {
        if (window.innerWidth > 768 && !e.target.closest('.main-nav li')) {
            dropdownMenus.forEach(menu => {
                menu.style.opacity = '0';
                menu.style.visibility = 'hidden';
                menu.style.transform = 'translateY(10px)';
            });
        }
    });

    // ============ Animation trigger on scroll ============
    const cards = document.querySelectorAll('.animate-card');

    const animateOnScroll = function() {
        cards.forEach(card => {
            const cardPosition = card.getBoundingClientRect().top;
            const windowHeight = window.innerHeight;

            if (cardPosition < windowHeight - 100) {
                card.classList.add('show');
            }
        });
    };

    animateOnScroll(); // Initial check
    window.addEventListener('scroll', animateOnScroll);

    // ============ Initialize Swiper for news ============
    new Swiper('.news-swiper', {
        slidesPerView: 3,
        spaceBetween: 20,
        navigation: {
            nextEl: '.swiper-button-next',
            prevEl: '.swiper-button-prev',
        },
        breakpoints: {
            320: { slidesPerView: 1, spaceBetween: 10 },
            576: { slidesPerView: 2, spaceBetween: 15 },
            992: { slidesPerView: 3, spaceBetween: 20 }
        }
    });

});

// ============ Slideshow Class ============
class Slideshow {
    constructor(el) {
        this.DOM = { el: el };
        this.config = {
            slideshow: {
                delay: 3000,
                pagination: { duration: 3 }
            }
        };
        this.init();
    }

    init() {
        // Charmed title
        this.DOM.slideTitle = this.DOM.el.querySelectorAll('.slide-title');
        this.DOM.slideTitle.forEach(slideTitle => charming(slideTitle));

        // Initialize Swiper
        this.slideshow = new Swiper(this.DOM.el, {
            loop: true,
            autoplay: {
                delay: this.config.slideshow.delay,
                disableOnInteraction: false,
            },
            speed: 500,
            preloadImages: true,
            updateOnImagesReady: true,
            pagination: {
                el: '.slideshow-pagination',
                clickable: true,
                renderBullet: (index, className) => {
                    let number = (index <= 8) ? '0' + (index + 1) : (index + 1);
                    return `
                        <span class="slideshow-pagination-item">
                            <span class="pagination-number">${number}</span>
                            ${(index <= 8) ? '<span class="pagination-separator"><span class="pagination-separator-loader"></span></span>' : ''}
                        </span>
                    `;
                }
            },
            navigation: {
                nextEl: '.slideshow-navigation-button.next',
                prevEl: '.slideshow-navigation-button.prev',
            },
            scrollbar: { el: '.swiper-scrollbar' },
            on: { init: () => this.animate('next') }
        });

        this.initEvents();
    }

    initEvents() {
        this.slideshow.on('paginationUpdate', (swiper, paginationEl) => this.animatePagination(swiper, paginationEl));
        this.slideshow.on('slideNextTransitionStart', () => this.animate('next'));
        this.slideshow.on('slidePrevTransitionStart', () => this.animate('prev'));
    }

    animate(direction = 'next') {
        // Active slide
        const activeSlide = this.DOM.el.querySelector('.swiper-slide-active');
        const activeSlideImg = activeSlide.querySelector('.slide-image');
        const activeSlideTitle = activeSlide.querySelector('.slide-title');
        const activeSlideTitleLetters = direction === "next"
            ? activeSlideTitle.querySelectorAll('span')
            : Array.from(activeSlideTitle.querySelectorAll('span')).reverse();

        // Animate old slide
        const oldSlide = direction === "next"
            ? this.DOM.el.querySelector('.swiper-slide-prev')
            : this.DOM.el.querySelector('.swiper-slide-next');

        if (oldSlide) {
            const oldSlideTitleLetters = oldSlide.querySelectorAll('.slide-title span');
            oldSlideTitleLetters.forEach((letter, pos) => {
                TweenMax.to(letter, .3, {
                    ease: Quart.easeIn,
                    delay: (oldSlideTitleLetters.length - pos - 1) * .04,
                    y: '50%',
                    opacity: 0
                });
            });
        }

        // Animate active slide title
        activeSlideTitleLetters.forEach((letter, pos) => {
            TweenMax.to(letter, .6, {
                ease: Back.easeOut,
                delay: pos * .05,
                startAt: { y: '50%', opacity: 0 },
                y: '0%',
                opacity: 1
            });
        });

        // Animate background
        TweenMax.to(activeSlideImg, 1.5, {
            ease: Expo.easeOut,
            startAt: { x: direction === 'next' ? 200 : -200 },
            x: 0
        });
    }

    animatePagination(swiper, paginationEl) {
        const loaders = paginationEl.querySelectorAll('.pagination-separator-loader');
        const activeLoader = paginationEl.querySelector('.slideshow-pagination-item.active .pagination-separator-loader');

        TweenMax.set(loaders, { scaleX: 0 });
        TweenMax.to(activeLoader, this.config.slideshow.pagination.duration, {
            startAt: { scaleX: 0 },
            scaleX: 1
        });
    }
}

// Initialize slideshow
const slideshowEl = document.querySelector('.slideshow');
if (slideshowEl) {
    new Slideshow(slideshowEl);
}
